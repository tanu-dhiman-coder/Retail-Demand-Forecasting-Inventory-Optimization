from pathlib import Path
import pandas as pd
from src.data_prep import load_sales
from src.forecasting import seasonal_naive
from src.inventory import inventory_recommendation


def test_load_sales():
    df = load_sales(Path(__file__).parents[1] / "data" / "sample_sales.csv")
    assert not df.empty
    assert pd.api.types.is_datetime64_any_dtype(df["date"])


def test_forecast_horizon():
    result = seasonal_naive(pd.Series([1, 2, 3, 4, 5, 6, 7]), horizon=14)
    assert len(result) == 14
    assert (result.forecast >= 0).all()


def test_inventory_order_nonnegative():
    result = inventory_recommendation(10, 2, current_stock=5)
    assert result["recommended_order"] >= 0
