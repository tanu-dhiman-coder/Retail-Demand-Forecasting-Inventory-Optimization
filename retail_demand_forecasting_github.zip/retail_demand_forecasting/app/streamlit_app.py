from pathlib import Path
import sys
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))
from src.data_prep import load_sales, aggregate_daily
from src.forecasting import seasonal_naive, moving_average
from src.inventory import inventory_recommendation

st.set_page_config(page_title="Retail Demand Forecasting", page_icon="📦", layout="wide")
st.title("📦 Retail Demand Forecasting & Inventory Optimization")
st.caption("A portfolio-ready analytics dashboard for proactive retail replenishment.")

sales = load_sales(ROOT / "data" / "sample_sales.csv")

with st.sidebar:
    st.header("Forecast Controls")
    store = st.selectbox("Store", sorted(sales.store_id.unique()))
    item = st.selectbox("Item", sorted(sales.item_id.unique()))
    horizon = st.slider("Forecast horizon (days)", 7, 60, 30)
    model = st.selectbox("Forecast model", ["Seasonal Naive", "Moving Average"])
    current_stock = st.number_input("Current stock", min_value=0, value=100, step=10)
    lead_time = st.slider("Supplier lead time (days)", 1, 30, 7)

filtered = sales[(sales.store_id == store) & (sales.item_id == item)].copy()
daily = aggregate_daily(sales, store, item)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Historical units", f"{int(filtered.sales.sum()):,}")
col2.metric("Average daily demand", f"{filtered.sales.mean():.1f}")
col3.metric("Promotion days", f"{int(filtered.promotion.sum())}")
col4.metric("Average price", f"₹{filtered.price.mean():,.0f}")

if model == "Seasonal Naive":
    forecast = seasonal_naive(daily.sales, horizon=horizon)
else:
    forecast = moving_average(daily.sales, horizon=horizon)

forecast["date"] = pd.date_range(daily.date.max() + pd.Timedelta(days=1), periods=horizon)
forecast["forecast"] = forecast.forecast.round(2)

history_plot = daily.rename(columns={"sales": "units"})
history_plot["type"] = "Actual"
forecast_plot = forecast.rename(columns={"forecast": "units"})[["date", "units"]]
forecast_plot["type"] = "Forecast"
chart_df = pd.concat([history_plot[["date", "units", "type"]], forecast_plot])

st.subheader("Demand trend and forecast")
fig = px.line(chart_df, x="date", y="units", color="type", markers=True,
              labels={"date": "Date", "units": "Units", "type": "Series"})
st.plotly_chart(fig, use_container_width=True)

avg = float(forecast.forecast.mean())
std = float(daily.sales.std(ddof=0)) if len(daily) > 1 else 0.0
recommendation = inventory_recommendation(avg, std, lead_time_days=lead_time,
                                          current_stock=current_stock)

st.subheader("Inventory recommendation")
a, b, c, d = st.columns(4)
a.metric("Safety stock", recommendation["safety_stock"])
b.metric("Reorder point", recommendation["reorder_point"])
c.metric("Target stock", recommendation["target_stock"])
d.metric("Recommended order", recommendation["recommended_order"])

st.info("Interpretation: place a replenishment order when available inventory reaches the reorder point. The recommended order quantity raises stock toward the target level.")

st.subheader("Forecast table")
st.dataframe(forecast[["date", "forecast"]], use_container_width=True, hide_index=True)
