# Retail Demand Forecasting & Inventory Optimization

A professional, portfolio-ready analytics project for retail and supply-chain teams. It forecasts product demand from historical sales and converts forecasts into practical replenishment recommendations.

## Business Objective

- Reduce stockouts for high-demand products.
- Reduce excess inventory and warehousing cost.
- Support proactive, data-driven procurement.
- Allow managers to test pricing and demand scenarios.

## Architecture

```text
Historical Sales CSV / M5 Dataset
            |
            v
      Data Preparation
            |
            v
      Feature Engineering
            |
            v
   Forecasting Model Layer
   - Seasonal Naive baseline
   - Moving Average baseline
   - Optional Prophet / LightGBM
            |
            v
 Inventory Optimization
 - Safety stock
 - Reorder point
 - Recommended order quantity
            |
            v
     Streamlit Dashboard
```

## Tech Stack

- Python 3.10+
- Pandas, NumPy, scikit-learn
- Streamlit
- Plotly
- SQL
- Optional: BigQuery/Snowflake + dbt

## Project Structure

```text
retail_demand_forecasting/
├── app/
│   └── streamlit_app.py
├── data/
│   └── sample_sales.csv
├── dbt/
│   └── models/
│       └── fct_daily_sales.sql
├── sql/
│   └── warehouse_schema.sql
├── src/
│   ├── data_prep.py
│   ├── forecasting.py
│   └── inventory.py
├── tests/
│   └── test_pipeline.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Quick Start

### 1. Create and activate a virtual environment

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Run the dashboard

```bash
streamlit run app/streamlit_app.py
```

### 4. Run tests

```bash
pytest
```

## Using the M5 Dataset

Download the Walmart M5 Forecasting dataset from Kaggle and place the relevant daily sales file in `data/`. The sample application works immediately with `data/sample_sales.csv`; replace it with a transformed M5 file when ready.

Expected columns:

- `date`
- `store_id`
- `item_id`
- `department`
- `sales`
- `price`
- `promotion`

## GitHub Upload

```bash
git init
git add .
git commit -m "Initial retail demand forecasting project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/retail-demand-forecasting.git
git push -u origin main
```

## Production Enhancements

1. Replace baseline forecasts with Prophet, LightGBM, or a hybrid ensemble.
2. Add BigQuery/Snowflake ingestion and dbt transformations.
3. Add model monitoring, forecast accuracy tracking, and drift detection.
4. Add authentication and role-based dashboard access.
5. Add automated email alerts for stockout risk.
