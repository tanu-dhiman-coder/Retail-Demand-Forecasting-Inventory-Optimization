import math


def inventory_recommendation(avg_daily_demand: float, demand_std: float, lead_time_days: int = 7,
                             service_level_z: float = 1.65, current_stock: int = 0,
                             review_period_days: int = 7) -> dict:
    safety_stock = service_level_z * demand_std * math.sqrt(max(lead_time_days, 1))
    reorder_point = avg_daily_demand * lead_time_days + safety_stock
    target_stock = avg_daily_demand * (lead_time_days + review_period_days) + safety_stock
    recommended_order = max(0, math.ceil(target_stock - current_stock))
    return {
        "safety_stock": round(safety_stock, 2),
        "reorder_point": round(reorder_point, 2),
        "target_stock": round(target_stock, 2),
        "recommended_order": recommended_order,
    }
