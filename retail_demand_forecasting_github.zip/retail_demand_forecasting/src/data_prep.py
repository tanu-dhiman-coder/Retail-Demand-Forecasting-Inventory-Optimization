from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = {"date", "store_id", "item_id", "department", "sales", "price", "promotion"}


def load_sales(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    df["date"] = pd.to_datetime(df["date"])
    df["sales"] = pd.to_numeric(df["sales"], errors="coerce").fillna(0).clip(lower=0)
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df["promotion"] = pd.to_numeric(df["promotion"], errors="coerce").fillna(0).astype(int)
    return df.sort_values("date").reset_index(drop=True)


def aggregate_daily(df: pd.DataFrame, store_id: str, item_id: str) -> pd.DataFrame:
    subset = df[(df.store_id == store_id) & (df.item_id == item_id)].copy()
    return subset.groupby("date", as_index=False)["sales"].sum().sort_values("date")
