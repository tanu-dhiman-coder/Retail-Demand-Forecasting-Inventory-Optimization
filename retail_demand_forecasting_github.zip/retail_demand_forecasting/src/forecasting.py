import numpy as np
import pandas as pd


def seasonal_naive(series: pd.Series, horizon: int = 30, season_length: int = 7) -> pd.DataFrame:
    values = series.astype(float).to_numpy()
    if len(values) == 0:
        raise ValueError("At least one historical observation is required")
    recent = values[-season_length:] if len(values) >= season_length else np.repeat(values[-1], season_length)
    forecast = np.resize(recent, horizon)
    return pd.DataFrame({"day": range(1, horizon + 1), "forecast": np.maximum(forecast, 0)})


def moving_average(series: pd.Series, horizon: int = 30, window: int = 7) -> pd.DataFrame:
    values = series.astype(float).to_numpy()
    if len(values) == 0:
        raise ValueError("At least one historical observation is required")
    window_values = values[-window:] if len(values) >= window else values
    forecast_value = float(np.mean(window_values))
    return pd.DataFrame({"day": range(1, horizon + 1), "forecast": max(forecast_value, 0)})
