{{ config(materialized='table') }}

select
    cast(date as date) as sales_date,
    store_id,
    item_id,
    department,
    cast(sales as integer) as sales_units,
    cast(price as numeric) as price,
    cast(promotion as boolean) as promotion_flag
from {{ source('retail', 'raw_sales') }}
where sales >= 0
