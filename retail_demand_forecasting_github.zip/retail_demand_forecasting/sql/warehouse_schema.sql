CREATE TABLE IF NOT EXISTS fct_daily_sales (
    sales_date DATE NOT NULL,
    store_id VARCHAR(50) NOT NULL,
    item_id VARCHAR(50) NOT NULL,
    department VARCHAR(100),
    sales_units INTEGER NOT NULL,
    price DECIMAL(12,2),
    promotion_flag BOOLEAN,
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sales_store_item_date
ON fct_daily_sales(store_id, item_id, sales_date);
